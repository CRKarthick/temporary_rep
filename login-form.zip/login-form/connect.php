<?php

$mongo = new MongoClient();

$db = $mongo -> mydb;

$col = $db -> reg;

if(isset($_POST['user'])){
	$user = $_POST['user'];
}
if(isset($_POST['pass'])){
	$pass = $_POST['pass'];
}

$document = array(
	"username" => $user,
	"password" => $pass
);

$res = $col -> findOne($document);
if ($res){
	echo "User logged in successfully";
}
else{
	echo "Username and password is not available";
	#header("Location: register.php");
}

 ?>
